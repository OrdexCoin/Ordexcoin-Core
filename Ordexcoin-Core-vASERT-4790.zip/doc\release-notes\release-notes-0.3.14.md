Version 0.3.14 is now available
http://sourceforge.net/projects/ordexcoin/files/OrdexCoin/ordexcoin-0.3.14/

Changes:
* Key pool feature for safer wallet backup
Gavin Andresen:
* TEST network mode with switch -testnet
* Option to use SSL for JSON-RPC connections on unix/osx
* validateaddress RPC command
eurekafag:
* Russian translation
