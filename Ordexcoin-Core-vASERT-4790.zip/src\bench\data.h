// Copyright (c) 2019 The Bitcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef ORDEXCOIN_BENCH_DATA_H
#define ORDEXCOIN_BENCH_DATA_H

#include <cstdint>
#include <vector>

namespace benchmark {
namespace data {

extern const std::vector<uint8_t> block413567;

} // namespace data
} // namespace benchmark

#endif // ORDEXCOIN_BENCH_DATA_H
